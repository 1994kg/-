package com.kgitbank.mvc05;

import java.util.ArrayList;
import java.util.List;

public class GenericTest2 {

	public static void main(String[] args) {
		List<BbsDTO> list = new ArrayList<BbsDTO>();
		//Ÿ���� ��ü ������ ����!!!
		BbsDTO dto = new BbsDTO();
		dto.setId("100");
		dto.setTitle("100");
		dto.setContent("100");
		dto.setWriter("100");
		
		BbsDTO dto2 = new BbsDTO();
		dto2.setId("200");
		dto2.setTitle("200");
		dto2.setContent("200");
		dto2.setWriter("200");
		
		list.add(dto);
		list.add(dto2);
		
		BbsDTO dto3 = list.get(0);
		
	}
}





