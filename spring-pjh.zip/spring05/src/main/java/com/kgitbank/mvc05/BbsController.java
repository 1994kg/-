package com.kgitbank.mvc05;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BbsController {
	
	@Autowired
	BbsDAO dao;
	
	@RequestMapping("bbs_searchAll")
	public void selectAll(Model model) {
		List<BbsDTO> list = dao.selectAll();
		model.addAttribute("list", list);
		for (BbsDTO x : list) {
			System.out.println(x.getId());
			System.out.println(x.getTitle());
			System.out.println(x.getContent());
			System.out.println(x.getWriter());
			
			System.out.println("-------------");
		}
	}
	
	@RequestMapping("selectOne")
	public void selectOne(BbsDTO bbsDTO, Model model) {
		BbsDTO dto = dao.selectOne(bbsDTO);
		//model�� �Ӽ����� ����س�����,
		//views�Ʒ����� �� �����Ͱ� �Ѿ��.
		model.addAttribute("dto", dto);
		System.out.println(dto);
	}
	
	
	@RequestMapping("insertBbs")
	public String insertBbs(BbsDTO bbsDTO) {
		//dbó�� Ŭ���� �޼ҵ� ȣ��
		 dao.insert(bbsDTO);
		 return "insertResult";
	}
}
