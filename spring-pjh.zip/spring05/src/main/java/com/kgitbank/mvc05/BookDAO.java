package com.kgitbank.mvc05;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BookDAO {

	@Autowired
	SqlSessionTemplate my; 
	
	public void insert(BookDTO bookDTO) {
		my.insert("book.insert", bookDTO);
	}
	
}
