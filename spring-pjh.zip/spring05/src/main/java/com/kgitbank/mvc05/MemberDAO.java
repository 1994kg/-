package com.kgitbank.mvc05;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class MemberDAO {

	@Autowired
	SqlSessionTemplate mem;
	
	public void insert(MemberDTO memberDTO) {
		mem.insert("member.insertMem", memberDTO);
	}
	
}
