package com.kgitbank.mvc04;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CheckController {

	@Autowired
	ReplyDAO dao; //������ ����(di)
	
	@RequestMapping("call6.kg")
	public void check(String id, Model model) {
		System.out.println(id);
		//dbó��
		String saveId = "kgjava";
		String result = "";
		if(id.equals(saveId)) {
			result = "�α���ok";
		}else {
			result = "�α���not";
		}
		model.addAttribute("result", result);
	}
	
	@RequestMapping("reply.kg")
	public void reply(String reply, Model model) {
		System.out.println(reply);
		//dbó��
		dao.insert(reply);
		
		model.addAttribute("reply", reply);
	}
}






