package com.kgitbank.mvc04;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.stereotype.Repository;

@Repository
public class ReplyDAO {
	Connection con;
	
	public ReplyDAO() {
		try {
			//model
			//1. Ŀ���� ����
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. Ŀ���� ���� ok...");
			
			//2. db����
			String url = "jdbc:mysql://localhost:3309/spring";
			String user = "root";
			String password = "1234";
			con = DriverManager.getConnection(url, user, password);
			System.out.print("2. db ���� ok...");
		} catch (Exception e) {
		}
	}
	
	
	public void insert(String content) {
		try {
			//3. sql�� ����
			String sql = "insert into reply(content) values (?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, content);
			
			System.out.print("3. SQL�� ��üȭ ok...");
			
			ps.executeUpdate();
			
			//view
			System.out.print("4. sql�� ���� ok....!");
		} catch (Exception e) {
		}
		
	}
}
