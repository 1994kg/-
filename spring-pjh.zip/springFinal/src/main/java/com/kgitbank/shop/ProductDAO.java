package com.kgitbank.shop;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

//싱글톤
@Repository
public class ProductDAO {

	@Autowired
	SqlSessionTemplate myBatis;
	
	public List<ProductDTO> list() {
		return myBatis.selectList("product.list");
	}
}
