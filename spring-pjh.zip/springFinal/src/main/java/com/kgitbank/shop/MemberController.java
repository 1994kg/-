package com.kgitbank.shop;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MemberController {

	@Autowired
	MemberDAO dao;
	
	//수정 후 반영
	@RequestMapping("updateMember2")
	public String update(MemberDTO memberDTO) {
		dao.update(memberDTO);
		return "redirect:member.jsp";
		
	}
	
	//수정전 검색
	@RequestMapping("updateMember")
	public String select(MemberDTO memberDTO, Model model) {
		MemberDTO dto = dao.select(memberDTO);
		model.addAttribute("dto2", dto);
		return "member_update";
	}
	
	
	@RequestMapping("insertMember")
	public String insert(MemberDTO memberDTO) {
		dao.insert(memberDTO);
		return "redirect:member.jsp";
	}
	
	
	@RequestMapping("login")
	public String login(MemberDTO memberDTO, HttpSession session) {
		int result = dao.login(memberDTO);
		if(result == 1) {
			//로그인 ok처리
			session.setAttribute("id", memberDTO.getId());
			
		}else {
			//로그인 not처리
		}
		return "redirect:member.jsp";
		
	}
}
