package com.kgitbank.shop;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ProductController {

	@Autowired
	ProductDAO dao;
	
	@RequestMapping("productList")
	public void list(Model model) {
		List<ProductDTO> list = dao.list();
		model.addAttribute("list", list);
	}
}
