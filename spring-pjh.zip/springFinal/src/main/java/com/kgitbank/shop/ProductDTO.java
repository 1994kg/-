package com.kgitbank.shop;

public class ProductDTO {

	private String id;
	private String title;
	private int price;
	private String info;
	private String img;
	
	
	
	@Override
	public String toString() {
		return "ProductDTO [id=" + id + ", title=" + title + ", price=" + price + ", info=" + info + ", img=" + img
				+ "]";
	}
	
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	
	
}
