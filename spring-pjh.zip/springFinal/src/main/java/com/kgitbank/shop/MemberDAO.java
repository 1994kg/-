package com.kgitbank.shop;


import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class MemberDAO {

	//DB 처리할 객체의 주소 => myBatis
	@Autowired
	SqlSessionTemplate myBatis;
	
	public void insert(MemberDTO memberDTO) {
						//네임스페이스.id
		myBatis.insert("member.insert", memberDTO);
	
	}
	public MemberDTO select(MemberDTO memberDTO) {
		return myBatis.selectOne("member.select", memberDTO);
		
	}
	
	public void update(MemberDTO memberDTO) {
		myBatis.update("member.update", memberDTO);
	}
	
	public int login(MemberDTO memberDTO) {
		MemberDTO dto = myBatis.selectOne("member.login", memberDTO);
		int result = 0;	//id, pw가진 사람이 없음.
		if(dto != null) {	//null이 아니면 이란 뜻은 로그인한(그 id, pw 를 가진 사람이) 있다는 뜻.
			result = 1;	//리턴이 1이면 로그인 ok, 아니라면 로그인 not
		}
		return result;
	}
}
